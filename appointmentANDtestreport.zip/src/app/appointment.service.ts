import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

  url:string='http://localhost:8080/appointment/';

  constructor(private http:HttpClient) { }

  getAllAppointment()
  {
    return this.http.get(this.url);
  }

  getAllDoctors()
  {
    return this.http.get(this.url);
  }

  findAppointmentById(appointmentId:string)
  {
    return this.http.get(this.url+appointmentId);
  }

  addAppointment(appointment:any)
  {
    return this.http.post(this.url,appointment);
  }

  modifyAppointment(appointment:any)
  {
    return this.http.put(this.url,appointment);
  }

  deleteAppointment(appointmentId:string)
  {
    return this.http.delete(this.url+appointmentId)
  }
}
