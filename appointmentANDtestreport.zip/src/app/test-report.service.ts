import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestReportService {
  url: string = 'http://localhost:8080/testreport/'

  constructor(private http:HttpClient) { }

  getAllTestReport()
  {
    return this.http.get(this.url);
  }
  findTestReportById(testReportId:string)
  {
    return this.http.get(this.url+testReportId);
  }

  addTestReport(testReport:any)
  {
    return this.http.post(this.url,testReport);
  }
 
  modifyTestReport(testReport:any)
  {
    return this.http.put(this.url,testReport);
  }

  deleteTestReport(testReportId:string)
  {
    return this.http.delete(this.url+testReportId);
  }


}
