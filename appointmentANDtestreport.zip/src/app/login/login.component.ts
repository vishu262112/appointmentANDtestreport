import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  message ='';
  name:string;
  password:string;


  constructor( private authService:AuthService,private router:Router,private activated:ActivatedRoute) {
    this.name='';
    this.password='';
   }

  ngOnInit(): void {
  }

  onSubmit()
  {
    if(this.authService.authenticate(this.name,this.password))
    {
      this.router.navigate([{outlets:{'col2':['display']}}]);
    }
    else{
      this.message='Your userName or password is incorrect';
    }

  }

}
