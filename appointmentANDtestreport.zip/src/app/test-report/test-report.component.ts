import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

import { TestReportService } from '../test-report.service';

@Component({
  selector: 'app-test-report',
  templateUrl: './test-report.component.html',
  styleUrls: ['./test-report.component.css']
})
export class TestReportComponent implements OnInit {

  testReportForm:any;
  testReports:any;
  constructor(private fb:FormBuilder,private trs:TestReportService) {
    this.testReportForm = this.fb.group({
      testReportId:[''],
      patientId:['134'],
      testId:['too1'],
      technicianId:['T002'],
      billingPrice:['233'],
      result:['negative']
    });
   }

  ngOnInit(): void {
  }

  get form()
  {
    return this.testReportForm.controls;
  }

 getAllTestReport()
 {
   this.trs.getAllTestReport().subscribe((data)=>{
     console.log(data);
     this.testReports = data;
   })
 }

 testReportAdd()
 {
   var formData = new FormData();
   formData.append('patientId',this.testReportForm.controls.patientId.value);
   formData.append('testId',this.testReportForm.controls.testId.value);
   formData.append('technicianId',this.testReportForm.controls.technicianId.value);
   formData.append('billingPrice',this.testReportForm.controls.billingPrice.value);
   formData.append('result',this.testReportForm.controls.result.value);

   console.log(formData);
   this.trs.addTestReport(formData).subscribe((data:any)=>{
     console.log(data);
     this.getAllTestReport();
   });
 }

testReportModify()
{
  var formData = new FormData();
  formData.append('testReportId',this.testReportForm.controls.testReportId.value);
   formData.append('patientId',this.testReportForm.controls.patientId.value);
   formData.append('testId',this.testReportForm.controls.testId.value);
   formData.append('technicianId',this.testReportForm.controls.technicianId.value);
   formData.append('billingPrice',this.testReportForm.controls.billingPrice.value);
   formData.append('result',this.testReportForm.controls.result.value);

   console.log(formData);
   this.trs.modifyTestReport(formData).subscribe((data:any)=>{
     console.log(data);
     this.getAllTestReport();
   });
}
testReportDelete()
{
  alert("hello")
}

}
