package com.mphasis.laboratory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.laboratory.entity.Technician;
import com.mphasis.laboratory.service.TechnicianService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
@RequestMapping("/technician")
public class TechnicianController {
	
	@Autowired
	TechnicianService ts;
	
	@GetMapping("/")
	public List<Technician> getAllTechnician()
	{
		List<Technician> technician = ts.read();
		return technician;
	}
	
	@GetMapping("/{technicianId}")
	public Technician findTechnicianById(@PathVariable("technicianId") String technicianId)
	{
		return ts.read(technicianId);
	}
	
	@PostMapping("/")
	public Technician addTechnician(@RequestBody Technician technician)
	{
		return ts.create(technician);
	}
	
	@PutMapping("/")
	public Technician modifyTechnician(@RequestBody Technician technician)
	{
		return ts.update(technician);
	}
	
	@DeleteMapping("/{technicianId}")
	public  void deleteTechnician(@PathVariable("technicianId") String technicianId) 
	{
		ts.delete(technicianId);
	}
	

}
