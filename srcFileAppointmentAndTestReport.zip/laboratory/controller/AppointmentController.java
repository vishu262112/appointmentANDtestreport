package com.mphasis.laboratory.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.laboratory.entity.Appointment;
import com.mphasis.laboratory.entity.Doctor;
import com.mphasis.laboratory.entity.MedicalTest;
import com.mphasis.laboratory.entity.Patient;
import com.mphasis.laboratory.entity.Technician;
import com.mphasis.laboratory.service.AppointmentService;
import com.mphasis.laboratory.service.DoctorService;
import com.mphasis.laboratory.service.MedicalTestService;
import com.mphasis.laboratory.service.PatientService;
@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
@RequestMapping("/appointment")

public class AppointmentController{
	
		
		@Autowired 
		AppointmentService appointmentService;
		@Autowired
		PatientService patientService;
		@Autowired
		DoctorService doctorService;
		@Autowired
		MedicalTestService medicalTestService;
		
		@GetMapping("/")
		public List<Appointment> retrieveAllAppointments()
		{
			List<Appointment>appointments= appointmentService.read();
			return appointments;
		}
		
		@GetMapping("/doctor")
		public List<Doctor> retrieveAllDoctors()
		{
			List<Doctor> doctors = doctorService.read();
			System.err.println(doctors);
			return doctors;
		}
		
		
		@GetMapping("/{appointmentId}")
		public Appointment findAppointmentById(@PathVariable("appointmentId") Long appointmentId)
		{
			return appointmentService.read(appointmentId);
		}
		
		@PostMapping("/")
		public Appointment addAppointment(@RequestParam("appointmentDate") String appointmentDate, @RequestParam("timeSlot") String timeSlot, @RequestParam("patientId") Long patientId,@RequestParam("testId") String testId,@RequestParam("doctorId") String doctorId) throws ParseException
		{
			
			Appointment appointment = new Appointment();
			appointment.setAppointmentDate(new SimpleDateFormat("yyyy-MM-dd").parse(appointmentDate));
			appointment.setTimeSlot(timeSlot);
			
			Patient patient = patientService.read(patientId);
			appointment.setPatient(patient);
			
			MedicalTest test = medicalTestService.read(testId);
			appointment.setMedicaltest(test);
			
			Doctor doctor = doctorService.read(doctorId);
			appointment.setDoctor(doctor);
			
//			System.out.println("Adding the appointment: "+appointment);
			return appointmentService.create(appointment);
		}
		
		
																		

	
		
		
		@PutMapping("/")
		public Appointment modifyAppointment(@RequestParam("appointmentId") Long appointmentId,@RequestParam("appointmentDate") String appointmentDate, @RequestParam("timeSlot") String timeSlot, @RequestParam("patientId") Long patientId,@RequestParam("testId") String testId,@RequestParam("doctorId") String doctorId) throws ParseException
		{
			Appointment appointment = new Appointment();
			appointment.setAppointmentId(appointmentId);
			appointment.setAppointmentDate(new SimpleDateFormat("yyyy-MM-dd").parse(appointmentDate));
			appointment.setTimeSlot(timeSlot);
			
			Patient patient = patientService.read(patientId);
			appointment.setPatient(patient);
			
			MedicalTest test = medicalTestService.read(testId);
			appointment.setMedicaltest(test);
			
			Doctor doctor = doctorService.read(doctorId);
			appointment.setDoctor(doctor);
			
			System.out.println("Adding the appointment: "+appointment);
			
			return appointmentService.update(appointment);
		}
		@DeleteMapping("/{appointmentId}")
		public void deleteAppointment(@PathVariable("appointmentId") Long appointmentId)
		{
			appointmentService.delete(appointmentId);
		}
	
	
	
	
	
	

}
