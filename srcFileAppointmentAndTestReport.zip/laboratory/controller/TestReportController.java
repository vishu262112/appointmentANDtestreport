package com.mphasis.laboratory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.laboratory.entity.MedicalTest;
import com.mphasis.laboratory.entity.Patient;
import com.mphasis.laboratory.entity.Technician;
import com.mphasis.laboratory.entity.TestReport;
import com.mphasis.laboratory.service.MedicalTestService;
import com.mphasis.laboratory.service.PatientService;
import com.mphasis.laboratory.service.TechnicianService;
import com.mphasis.laboratory.service.TestReportService;


@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
@RequestMapping("/testreport")
public class TestReportController {
@Autowired
TestReportService testreportService;

@Autowired
PatientService patientService;

@Autowired
MedicalTestService medicalTestService;

@Autowired
TechnicianService technicianService;
@GetMapping("/")
public List<TestReport> retrieveAllTestReports()
{
	List<TestReport>testreports= testreportService.read();
	return testreports;
}
@GetMapping("/{testReportId}")
public TestReport findTestReportById(@PathVariable("testReportId") Long testReportId)
{
	return testreportService.read(testReportId);
}
@PostMapping("/")
public TestReport addTestReport(@RequestParam("billingPrice") String billingPrice,@RequestParam("result") String result, @RequestParam("patientId") Long patientId,@RequestParam("testId") String testId,@RequestParam("technicianId") String technicianId)
{
	TestReport testReport = new TestReport();
	testReport.setbillingPrice(billingPrice);
	testReport.setResult(result);
	
	System.out.println("bill price"+billingPrice);
//	System.err.println("result"+result);
	
	Patient patient = patientService.read(patientId);
//	System.out.println("patient"+patient);
	testReport.setPatient(patient);
	
	
	
	MedicalTest medicalTest = medicalTestService.read(testId);
//	System.err.println("medicaltest"+medicalTest);
	testReport.setMedicaltest(medicalTest);
	
	
	
	Technician technician = technicianService.read(technicianId);
//	System.err.println("technician"+technician);
	testReport.setTechnician(technician);
	
	System.out.println(testReport);
	
	
	return testreportService.create(testReport);
}
@PutMapping("/")
public TestReport modifyTestReport(@RequestParam("testReportId") Long testReportId,@RequestParam("billingPrice") String billingPrice,@RequestParam("result") String result, @RequestParam("patientId") Long patientId,@RequestParam("testId") String testId,@RequestParam("technicianId") String technicianId)
{
	TestReport testReport = new TestReport();
	testReport.settestReportId(testReportId);
	testReport.setbillingPrice(billingPrice);
	testReport.setResult(result);
	
	System.out.println("bill price"+billingPrice);
//	System.err.println("result"+result);
	
	Patient patient = patientService.read(patientId);
//	System.out.println("patient"+patient);
	testReport.setPatient(patient);
	
	
	
	MedicalTest medicalTest = medicalTestService.read(testId);
//	System.err.println("medicaltest"+medicalTest);
	testReport.setMedicaltest(medicalTest);
	
	
	
	Technician technician = technicianService.read(technicianId);
//	System.err.println("technician"+technician);
	testReport.setTechnician(technician);
	
	System.out.println(testReport);
	return testreportService.update(testReport);
}
@DeleteMapping("/{testReportId}")
public void deleteTestReport(@PathVariable("testReportId") Long testReportId)
{
	testreportService.delete(testReportId);
}
	
}
