package com.mphasis.laboratory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.laboratory.entity.Doctor;
import com.mphasis.laboratory.entity.Patient;
import com.mphasis.laboratory.repository.DoctorRepository;

@Component("ds")
public class DoctorService {
	@Autowired
	DoctorRepository doctorRepo;
	public Doctor create(Doctor doctor)
	{
		return doctorRepo.save(doctor);
	}
	public List<Doctor> read()
	{
		return doctorRepo.findAll();
	}
	public Doctor read(String doctorId)
	{
		return doctorRepo.findById(doctorId).get();
	}
	public Doctor update(Doctor doctor)
	{
		return doctorRepo.save(doctor);
	}
	public void delete(String doctorId)
	{
		doctorRepo.delete(read(doctorId));
	}

}
