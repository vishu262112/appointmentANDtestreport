package com.mphasis.laboratory.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="APPOINTMENT")
public class Appointment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="appointmentId")
	private Long appointmentId;
	
	private Date	appointmentDate;
	private String	timeSlot;
	
	@JsonIgnore
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "patientId", nullable = false)
	    private Patient patient;
	
	@JsonIgnore
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "doctorId", nullable = false)
	    private Doctor doctor;
	
	@JsonIgnore
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "testId", nullable = false)
	    private MedicalTest medicaltest;
	 
	 
	 public Appointment() {}
	 
	 
	 public Appointment(Long appointmentId, Date appointmentDate, String timeSlot, Patient patient, Doctor doctor,
				MedicalTest medicaltest) {
			super();
			this.appointmentId = appointmentId;
			this.appointmentDate = appointmentDate;
			this.timeSlot = timeSlot;
			this.patient = patient;
			this.doctor = doctor;
			this.medicaltest = medicaltest;
		}
	
	
	
	
	public Patient getPatient() {
		return patient;
	}


	public void setPatient(Patient patient) {
		this.patient = patient;
	}


	public Doctor getDoctor() {
		return doctor;
	}


	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}


	public MedicalTest getMedicaltest() {
		return medicaltest;
	}


	public void setMedicaltest(MedicalTest medicaltest) {
		this.medicaltest = medicaltest;
	}


	public Long getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	
	
	
	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", appointmentDate=" + appointmentDate + ", timeSlot="
				+ timeSlot + ", patient=" + patient + ", doctor=" + doctor + ", medicaltest=" + medicaltest + "]";
	}
	
	
	
}