package com.mphasis.laboratory.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="MedicalTest")
public class MedicalTest  implements Serializable{
	
	@Id 
	private String testId;
	private String testName;
	private String price;
	private String testCategory;
	 @OneToMany(cascade =  CascadeType.ALL,
	            mappedBy = "medicaltest")
	 private List<Appointment> appointmentList;
	 
	 @OneToOne(cascade= CascadeType.ALL,
			 mappedBy = "medicaltest")
	 private  TestReport testReport;
//	
	public MedicalTest() {}

	public MedicalTest(String testId, String testName, String price, String testCategory) {
		super();
		this.testId = testId;
		this.testName = testName;
		this.price = price;
		this.testCategory = testCategory;
	}

	public String getTestId() {
		return testId;
	}

	public void setTestId(String testId) {
		this.testId = testId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String gettestCategory() {
		return testCategory;
	}

	public void settestCategory(String testCategory) {
		this.testCategory = testCategory;
	}

	@Override
	public String toString() {
		return "MedicalTest [testId=" + testId + ", testName=" + testName + ", price=" + price + ", testCategory="
				+ testCategory + "]";
	}
	
	

}
