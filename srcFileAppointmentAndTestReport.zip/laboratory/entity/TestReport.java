package com.mphasis.laboratory.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="TESTREPORT")
public class TestReport {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
@Column(name = "testReportId")
private Long testReportId;

private String billingPrice;
private String result;

@JsonIgnore
@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "patientId", nullable = false)
private Patient patient;

@JsonIgnore
@OneToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "testId", nullable = false)
private MedicalTest medicaltest;

@JsonIgnore
@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "technicianId", nullable = false)
private Technician technician;

public TestReport() {}



public TestReport(Long testReportId, String billingPrice, String result, Patient patient, MedicalTest medicaltest,
		Technician technician) {
	super();
	this.testReportId = testReportId;
	this.billingPrice = billingPrice;
	this.result = result;
	this.patient = patient;
	this.medicaltest = medicaltest;
	this.technician = technician;
}



public Long gettestReportId() {
	return testReportId;
}
public void settestReportId(Long testReportId) {
	this.testReportId = testReportId;
}
public String getbillingPrice() {
	return billingPrice;
}
public void setbillingPrice(String billingPrice) {
	this.billingPrice = billingPrice;
}
public String getResult() {
	return result;
}
public void setResult(String result) {
	this.result = result;
}

public Patient getPatient() {
	return patient;
}



public void setPatient(Patient patient) {
	this.patient = patient;
}



public MedicalTest getMedicaltest() {
	return medicaltest;
}



public void setMedicaltest(MedicalTest medicaltest) {
	this.medicaltest = medicaltest;
}



public Technician getTechnician() {
	return technician;
}



public void setTechnician(Technician technician) {
	this.technician = technician;
}



@Override
public String toString() {
	return "TestReport [testReportId=" + testReportId + ", billingPrice=" + billingPrice + ", result=" + result
			+ ", patient=" + patient + ", medicaltest=" + medicaltest + ", technician=" + technician + "]";
}





}
