package com.mphasis.laboratory.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Technician")
public class Technician implements Serializable {
	@Id
	private String technicianId;
	private String technicianFirstName;
	private String technicianLastName;
	private String technicianEmailId;
	private String technicianPhoneNumber;
	
	 @OneToMany(cascade= CascadeType.ALL,mappedBy = "technician")
	 private List<TestReport> testReport;
	
	public Technician() {}

	public Technician(String technicianId, String technicianFirstName, String technicianLastName,
			String technicianEmailId, String technicianPhoneNumber) {
		super();
		this.technicianId = technicianId;
		this.technicianFirstName = technicianFirstName;
		this.technicianLastName = technicianLastName;
		this.technicianEmailId = technicianEmailId;
		this.technicianPhoneNumber = technicianPhoneNumber;
	}
	
	

	public String getTechnicianId() {
		return technicianId;
	}

	public void setTechnicianId(String technicianId) {
		this.technicianId = technicianId;
	}

	public String getTechnicianFirstName() {
		return technicianFirstName;
	}

	public void setTechnicianFirstName(String technicianFirstName) {
		this.technicianFirstName = technicianFirstName;
	}

	public String getTechnicianLastName() {
		return technicianLastName;
	}

	public void setTechnicianLastName(String technicianLastName) {
		this.technicianLastName = technicianLastName;
	}

	public String getTechnicianEmailId() {
		return technicianEmailId;
	}

	public void setTechnicianEmailId(String technicianEmailId) {
		this.technicianEmailId = technicianEmailId;
	}

	public String getTechnicianPhoneNumber() {
		return technicianPhoneNumber;
	}

	public void setTechnicianPhoneNumber(String technicianPhoneNumber) {
		this.technicianPhoneNumber = technicianPhoneNumber;
	}

	@Override
	public String toString() {
		return "Technician [technicianId=" + technicianId + ", technicianFirstName=" + technicianFirstName
				+ ", technicianLastName=" + technicianLastName + ", technicianEmailId=" + technicianEmailId
				+ ", technicianPhoneNumber=" + technicianPhoneNumber + "]";
	}
	
	
	
	

}
